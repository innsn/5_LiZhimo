    // 封装绘制风场图表的函数
    function drawWindChart(data) {
      var myChart = echarts.init(document.getElementById("main"));

      var maxMag = 32.1547;
      var minMag = 0;

      var series2 = [
        {
          type: "flowGL",
          coordinateSystem: "bmap",
          data: data,
          supersampling: 4,
          particleType: "line",
          particleDensity: 128,
          particleSpeed: 1,
          itemStyle: {
            opacity: 0.7,
          },
        },
      ];

      myChart.setOption({
        title: {
          text: "全国风场图",
          left: "left",
          textStyle: {
            color: "#fff",
          },
        },
        visualMap: {
          left: "right",
          min: minMag,
          max: maxMag,
          dimension: 4,
          inRange: {
            color: [
              "#313695",
              "#4575b4",
              "#74add1",
              "#abd9e9",
              "#e0f3f8",
              "#ffffbf",
              "#fee090",
              "#fdae61",
              "#f46d43",
              "#d73027",
              "#a50026",
            ],
          },
          realtime: false,
          calculable: true,
          textStyle: {
            color: "#fff",
          },
        },
        bmap: {
          center: [105, 38],
          zoom: 5,
          roam: true,
          mapStyle: {
            // Your map style configurations
             styleJson: [
          {
            featureType: "water",
            elementType: "all",
            stylers: {
              color: "#031628",
            },
          },
          {
            featureType: "land",
            elementType: "geometry",
            stylers: {
              color: "#000102",
            },
          },
          {
            featureType: "highway",
            elementType: "all",
            stylers: {
              visibility: "off",
            },
          },
          {
            featureType: "arterial",
            elementType: "geometry.fill",
            stylers: {
              color: "#000000",
            },
          },
          {
            featureType: "arterial",
            elementType: "geometry.stroke",
            stylers: {
              color: "#0b3d51",
            },
          },
          {
            featureType: "local",
            elementType: "geometry",
            stylers: {
              color: "#000000",
            },
          },
          {
            featureType: "railway",
            elementType: "geometry.fill",
            stylers: {
              color: "#000000",
            },
          },
          {
            featureType: "railway",
            elementType: "geometry.stroke",
            stylers: {
              color: "#08304b",
            },
          },
          {
            featureType: "subway",
            elementType: "geometry",
            stylers: {
              lightness: -70,
            },
          },
          {
            featureType: "building",
            elementType: "geometry.fill",
            stylers: {
              color: "#000000",
            },
          },
          {
            featureType: "all",
            elementType: "labels.text.fill",
            stylers: {
              color: "#857f7f",
            },
          },
          {
            featureType: "all",
            elementType: "labels.text.stroke",
            stylers: {
              color: "#000000",
            },
          },
          {
            featureType: "building",
            elementType: "geometry",
            stylers: {
              color: "#022338",
            },
          },
          {
            featureType: "green",
            elementType: "geometry",
            stylers: {
              color: "#062032",
            },
          },
          {
            featureType: "boundary",
            elementType: "all",
            stylers: {
              color: "#465b6c",
            },
          },
          {
            featureType: "manmade",
            elementType: "all",
            stylers: {
              color: "#022338",
            },
          },
          {
            featureType: "label",
            elementType: "all",
            stylers: {
              visibility: "off",
            },
          },
        ],
          },
        },
        series: series2,
      });
    }

    // 函数处理日期变化和数据更新
    function updateWindData(ymd) {
      var year = ymd.slice(0, 4);
      var month = ymd.slice(5, 7);
      var day = ymd.slice(8, 10);

      var filepath =
        "https://raw.githubusercontent.com/HE-DE/DATA_FOR_PROJECT/main/wind_csv/" +
        year +
        month +
        "/wind-" +
        year +
        month +
        day +
        "00.csv";

      var a = Promise.resolve(d3.csv(filepath));

      a.then(function (result) {
        var data = [];
        for (var i = 0; i < result.length; i++) {
          data.push([
            result[i]["lon"],
            result[i]["lat"],
            result[i]["U"],
            result[i]["V"],
            Math.sqrt(
              result[i]["U"] * result[i]["U"] + result[i]["V"] * result[i]["V"]
            ),
          ]);
        }
        drawWindChart(data); // 调用绘制函数更新图表
      });
    }

    // 日期选择器变化事件
    function change(event) {
      var date = document.querySelector("#date");
      var ymd = date.value;
      window.localStorage.ymd = ymd;
      updateWindData(ymd); // 更新风场数据
    }

// 监听 localStorage 变化事件
window.addEventListener('storage', event => {
  if (event.key === 'ymd') {
    const newDate = event.newValue;
    if (newDate) {
      updateWindData(newDate); // 更新风场数据
    }
  }
});

// 页面加载时初始化
document.addEventListener("DOMContentLoaded", function () {
  var savedDate = window.localStorage.ymd || "2013-01-01"; // 获取保存的日期
  updateWindData(savedDate); // 更新风场数据

  var input = document.querySelector("#date");
  input.addEventListener("input", change); // 监听日期选择器变化
});