function hotmap() {
  window.location.replace("../page/hotmap_for_country.html");
}

function windmap() {
  window.localStorage.year = year;
  window.localStorage.mon = month;
  window.localStorage.day = day;
  window.location.replace("../Echarts/echartsnglobal-wind.html");
}

function cluster() {
  window.location.replace("../page/cluster.html");
}

function cluster1() {
  window.location.replace("../page/cluster.html");
}

function cluster2(){
  window.location.replace("../page/hotmap_for_country.html");
}

function jump1(){
  window.location.replace("../page/line-race_meitan.html")
}
function jump2(){
  window.location.replace("../page/line-race_shiyou.html")
}
function jump3(){
  window.location.replace("../page/line_race_qiyou.html")
}