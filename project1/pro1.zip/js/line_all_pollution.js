
    province = window.localStorage.name;

    url = "../../data/" + province + '/pollution_factor_aqi' + ".json";

    function dataChange2(url) {
        console.log(url)
        $.get(url, function (data) {
                console.log(data)
                // 基于准备好的dom，初始化echarts实例
                let pollution_factor = ['AQI', 'PM2_5', 'PM10', 'SO2', 'NO2', 'CO', 'O3'];
                // console.log(pollution_factor)
                // console.log(data);
                // console.log(url.split('/'))
                // console.log(url.split('/')[2])
                var myChart = echarts.init(document.getElementById('Line_All_Pollution_Factor'));
                var option = {
                    title: {
                        text: url.split('/')[3],
                        x: 'center',
                        padding: 30
                    },
                    grid: {
                        left: "1%",
                        right: "4%",
                        bottom: "1%",
                        containLabel: true,
                    },
                    tooltip: {
                        trigger: 'axis',
                        formatter: function (params) {
                            var result = '';
                            result += params[0].name + '<br />';
                            for (var i = 0; i < params.length; i++) {
                                result += params[i].seriesName + ': ' + params[i].value + '<br />';
                            }
                            return result;
                        },
                        position: function (point, params, dom, rect, size) {
                            //  size为当前窗口大小
                            if ((size.viewSize[0] / 2) >= point[0]) {
                                //其中point为当前鼠标的位置
                                return [point[0] + 50, '10%'];
                            } else {
                                //其中point为当前鼠标的位置
                                return [point[0] - 200, '10%'];
                            }
                        },
                    },
                    legend: {
                        x: 'center',
                        y: 'top',
                        type: 'scroll',
                        // orient: 'vertical',
                        //unselect:
                        //     function (pollution_factor) {
                        //     let dic = new Array();
                        //     for (let i = 0; i < pollution_factor.size; i++) {
                        //         if (i === 0) {
                        //             dic[pollution_factor[i]] = 'true';
                        //         }
                        //         else{
                        //             dic[pollution_factor[i]] = 'false';
                        //         }
                        //     }
                        //     console.log(dic)
                        //     return dic;
                        // },
                        data: pollution_factor
                    },

                    dataZoom: [
                        {
                            height: 20, //时间滚动条的高度
                            type: 'slider', //type的作用是指定数据缩放的类型，slider表示使用滑动条进行缩放，inside表示使用鼠标滚轮进行缩放。
                            xAxisIndex: 0, //作用在x轴的下标（因为x轴可以有多个）
                            minValueSpan: 6,
                            filterMode: 'filter', //间滚动条的过滤模式,'filter'表示滑动时间条时会直接过滤掉不在时间范围内的数据，'weakFilter'表示滑动时间条时会逐渐过滤掉不在时间范围内的数据。
                            start: 0,  //默认开始位置（百分比）
                            end: 1,  //默认结束位置（百分比）
                        },
                        {
                            type: 'inside',
                            xAxisIndex: 0,
                            filterMode: 'filter',
                            start: 0,
                            end: 100,
                        },
                    ],
                    xAxis: [
                        {
                            type: 'category',
                            boundaryGap: false,
                            data: data[7]
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                        }
                    ],
                    series: []
                };


                //折线图数据加载
                $(document).ready(function () {
                    var Item = function () {
                        return {
                            name: '',
                            type: 'line',
                            // stack: '总量',
                            smooth: 'true',
                            itemStyle: {data: []}
                        }
                    };
                    var Series = [];
                    var values = [];
                    for (var i = 0; i < data.length - 1; i++) {
                        values = [];
                        var it = new Item();
                        it.name = pollution_factor[i];
                        values = data[i];
                        // console.log(data[i]);
                        it.data = values;
                        Series.push(it);
                    }

                    option.series = Series; // 设置图表
                    myChart.setOption(option);// 重新加载图表
                });


                // 图例点击事件
                var triggerAction = function (action, selected) {
                    legend = [];

                    for (name in selected) {
                        if (selected.hasOwnProperty(name)) {
                            legend.push({name: name});
                        }
                    }

                    myChart.dispatchAction({
                        type: action,
                        batch: legend
                    });
                };

                var isFirstUnSelect = function (selected) {

                    var unSelectedCount = 0;
                    for (name in selected) {
                        if (!selected.hasOwnProperty(name)) {
                            continue;
                        }

                        if (selected[name] == false) {
                            ++unSelectedCount;
                        }
                    }
                    return unSelectedCount == 1;
                };

                var isAllUnSelected = function (selected) {
                    var selectedCount = 0;
                    for (name in selected) {
                        if (!selected.hasOwnProperty(name)) {
                            continue;
                        }

                        // 所有 selected Object 里面 true 代表 selected， false 代表 unselected
                        if (selected[name] == true) {
                            ++selectedCount;
                        }
                    }
                    return selectedCount == 0;
                };

                myChart.on('legendselectchanged', function (obj) {
                    var selected = obj.selected;
                    var legend = obj.name;

                    // 使用 legendToggleSelect Action 会重新触发 legendselectchanged Event，导致本函数重复运行
                    // 使得 无 selected 对象
                    if (selected != undefined) {

                        if (isFirstUnSelect(selected)) {
                            triggerAction('legendToggleSelect', selected);
                        } else if (isAllUnSelected(selected)) {
                            triggerAction('legendSelect', selected);

                        }
                    }

                });
            }
        )
    }
window.addEventListener('storage', event => {
    console.log('Storage event captured:', event);
    if (event.key == 'name') {
        province = event.newValue;
        url = "../../data/" + province + '/pollution_factor_aqi' + ".json";
        dataChange2(url);
    }
});

    dataChange2(url);
