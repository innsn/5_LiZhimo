var polu_dict = {
    "AQI": 1,
    "PM2.5(微克每立方米)": 2,
    "PM10(微克每立方米)": 3,
    "SO2(微克每立方米)": 4,
    "NO2(微克每立方米)": 5,
    "CO(毫克每立方米)": 6,
    "O3(微克每立方米)": 7,

};

const valueToShowRanges = {
  "AQI": [0, 50, 100, 150, 250, 350, 501],
  "PM2.5(微克每立方米)": [0, 50, 100, 150, 250, 350, 501],
 "PM10(微克每立方米)": [0, 50, 150, 250, 350, 500, 601],
  "SO2(微克每立方米)": [0, 50, 100, 150, 200, 300, 501],
 "NO2(微克每立方米)": [0, 30, 60, 90, 130, 150, 200],
  "CO(毫克每立方米)": [0, 2, 4, 14, 24, 36, 48],
 "O3(微克每立方米)":[0, 25, 40, 70, 100, 130, 180],
  "TEMP(K)":[233, 248, 258, 273, 288, 298, 308],
 "RH(%)": [20, 40, 60, 70, 80, 90, 100],
  "PSFC(Pa)":[40000, 60000, 70000, 80000, 90000, 95000, 100000],
};

var myChart = echarts.init(document.getElementById('main'));
var year = "2013";
var province = get_p2(window.localStorage.name);
var p2 = "山东";
var selectedIndicator="AQI";
function drawChart(selectedYear, selectedProvince, selectedIndicator) {
    $.ajax({
        type: "GET",
        url: "../../data/chart_data/" + selectedYear + ".csv",
        success: function (data) {
            var csvData = data;
            var dataArray = csvData.split('\n').map(row => row.split(','));

            var indicatorIndex = polu_dict[selectedIndicator]; // 获取指标对应的索引

            var aqiData = dataArray.slice(1).filter(row => row[0] == selectedProvince).map(row => {
                return {
                    name: row[8],
                    value: [
                        row[8],
                        parseFloat(row[indicatorIndex]) // 使用选定指标的索引获取相应的列数据
                    ]
                };
            });

            var option = {
                title: {
                        text: p2+"-"+selectedIndicator,
                        x: 'center',
                        padding: 5
                    },
                visualMap: {
                    show: false,
                    min: valueToShowRanges[selectedIndicator][0],
                    max: valueToShowRanges[selectedIndicator][6],
                },
                calendar: {
                    range: selectedYear,
                    cellSize: ['auto', 30]
                },
                 tooltip: {
                formatter: function (params) {
                         return '日期: ' + params.value[0] + '<br/>' +
                selectedIndicator + ': ' + params.value[1];
                         }
                 },
                series: {
                    type: 'heatmap',
                    coordinateSystem: 'calendar',
                    data: aqiData
                }
            };

            myChart.setOption(option);
        }
    });
}

function get_p2(p2){
  if (p2 == "安徽省") {
    p2 = "安徽";
  } else if (p2 == "北京市") {
    p2 = "北京";
  } else if (p2 == "重庆市") {
    p2 = "重庆";
  } else if (p2 == "福建省") {
    p2 = "福建";
  } else if (p2 == "甘肃省") {
    p2 = "甘肃";
  } else if (p2 == "广东省") {
    p2 = "广东";
  } else if (p2 == "广西壮族自治区") {
    p2 = "广西";
  } else if (p2 == "贵州省") {
    p2 = "贵州";
  } else if (p2 == "海南省") {
    p2 = "海南";
  } else if (p2 == "河北省") {
    p2 = "河北";
  } else if (p2 == "黑龙江省") {
    p2 = "黑龙江";
  } else if (p2 == "河南省") {
    p2 = "河南";
  } else if (p2 == "湖北省") {
    p2 = "湖北";
  } else if (p2 == "湖南省") {
    p2 = "湖南";
  } else if (p2 == "江苏省") {
    p2 = "江苏";
  } else if (p2 == "江西省") {
    p2 = "江西";
  } else if (p2 == "吉林省") {
    p2 = "吉林";
  } else if (p2 == "辽宁省") {
    p2 = "辽宁";
  } else if (p2 == "内蒙古自治区") {
    p2 = "内蒙古";
  } else if (p2 == "宁夏回族自治区") {
    p2 = "宁夏";
  } else if (p2 == "青海省") {
    p2 = "青海";
  } else if (p2 == "山东省") {
    p2 = "山东";
  } else if (p2 == "上海市") {
    p2 = "上海";
  } else if (p2 == "山西省") {
    p2 = "山西";
  } else if (p2 == "陕西省") {
    p2 = "陕西";
  } else if (p2 == "四川省") {
    p2 = "四川";
  } else if (p2 == "台湾省") {
    p2 = "台湾";
  } else if (p2 == "天津市") {
    p2 = "天津";
  } else if (p2 == "香港特别行政区") {
    p2 = "香港";
  } else if (p2 == "新疆维吾尔自治区") {
    p2 = "新疆";
  } else if (p2 == "西藏自治区") {
    p2 = "西藏";
  } else if (p2 == "云南省") {
    p2 = "云南";
  } else if (p2 == "浙江省") {
    p2 = "浙江";
  }
  return p2;
}

drawChart(year, province, "AQI"); // 初始化图表，使用 "AQI" 指标

window.addEventListener('storage', event => {
    if (event.key === 'name') {
        p2 = event.newValue;
        province = get_p2(p2);

        drawChart(year, province, selectedIndicator); // 以更新后的省份重新绘制图表，使用 "AQI" 指标
    } else if (event.key === 'ymd') {
        var ymd = event.newValue;
        year = ymd[0] + ymd[1] + ymd[2] + ymd[3];
        drawChart(year, province, selectedIndicator); // 以更新后的年份重新绘制图表，使用 "AQI" 指标
    }
    else if (event.key === 'currentIndicator') {
        selectedIndicator= event.newValue;
    drawChart(year, province, selectedIndicator);
    }
});

//// 切换指标示例
//var indicatorSelector = document.createElement("select");
//for (var indicator in polu_dict) {
//    var option = document.createElement("option");
//    option.value = indicator;
//    option.text = indicator;
//    indicatorSelector.appendChild(option);
//}
//indicatorSelector.addEventListener("change", function() {
//    var selectedIndicator = indicatorSelector.value;
//    drawChart(year, province, selectedIndicator); // 切换指标后重新绘制图表
//});
//document.body.appendChild(indicatorSelector);