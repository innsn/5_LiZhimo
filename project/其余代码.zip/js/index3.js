

/////////////////////////////////
//时间轴
const startDate = new Date("2013-01-01");
 const endDate = new Date("2018-12-31");
 // 计算日期范围内的总天数
const totalDays = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24));
 // 添加事件监听器以响应时间轴滑块的变化
const slider = document.getElementById("dateSlider");
slider.addEventListener("input", updateMapBySlider);
/////////////////////////////////////
const input = document.querySelector("#date");
input.addEventListener("input", change);
var date = document.querySelector("input[type='date']");
var ymd = "2013-01-01";
var year = "2013";
var month = "01";
var day = "01";
console.log(ymd);
var color = d3
    .scaleLinear() //AQI颜色比例尺
    .domain([0, 50, 100, 150, 200, 300, 501])
    .range([
        "#fef0d9",
        "#fdd49e",
        "#fdbb84",
        "#fc8d59",
        "#ef6548",
        "#d7301f",
        "#990000",
    ]);

var currentIndicator = "AQI"; // 默认显示 AQI 指标
function drawchinageo() {
    var url =
         "https://raw.githubusercontent.com/MOOS550W/DATA_FOR_PROJECT/main/country/" +
        year +
        month +
        "/CN-Reanalysis-daily-" +
        year +
        month +
        day +
        "00.csv";
    d3.json("../../json/china.json").then(function (data) {
        //读取地图数据
        var projection = d3
            .geoMercator() //投影
            .center([76, 37])
            .translate([100, 250])
            .scale(600);

        var geopath = d3
            .geoPath() //生成地图path
            .projection(projection);

        d3.select("svg").remove();
        var svg = d3
            .select("#hotmap") //画一个svg画布
            .append("svg")
            .attr("width", "900")
            .attr("height", "500");
        var g = svg.append("g").attr("id", "g"); //画出地图

        d3.select('svg').selectAll('geopath').remove();
        svg.selectAll("geopath")
            .data(data.features)
            .enter()
            .append("path")
            .attr("d", geopath)
            .on("mouseover",function(d,i){
                d3.select(this)
                    .attr("opacity","0.4");
            })
            .on("mouseout",function(d,i){
                d3.select(this)
                    .transition()
                    .duration(500)
                    .attr("opacity","0");
            })
            .on("click",function(n,d){
                window.localStorage.name = d.properties.name;
                window.localStorage.year = year;
                window.localStorage.mon = month;
                window.localStorage.day = day;
            })
            .attr("fill", "rgba(248,244,244)")
            .attr("opacity","0")

        var g1 = svg.select("g");

        d3.csv(url).then(function (alldata) {
            //获取空气数据
            console.log(alldata);
            var location = g1
                .selectAll(".location") //根据经纬度坐标coor的位置添加g元素
                .data(alldata)
                .enter()
                .append("g")
                .attr("class", "location")
                .attr("transform", function (d) {
                    //计算标注点的位置
                    var coor = projection([d["lon"], d["lat"]]);
                    return "translate(" + coor[0] + "," + coor[1] + ")";
                });
            location
                .append("circle")
                .attr("transform", `rotate(${8}) translate(0,0)`)
                .attr("r", 1.0);
            var rect = d3
                .selectAll(".location")
                .select("circle")
                .attr("fill", (d) => color(d[currentIndicator]));
            var valuetoshow = [0, 50, 100, 150, 200, 300, 501];
            svg
                .selectAll("#g")
                .append("rect")
                .attr("class", "legend")
                .attr("x", 750)
                .attr("y", 260)
                .attr("width", 25)
                .attr("height", 15)
                .attr("fill", "#fef0d9");
            svg
                .selectAll("#g")
                .append("text")
                .attr("class", "legend")
                .attr("y", 270)
                .attr("x", 780)
                .attr("fill","#aaa")
                .attr("font-size", 10)
                .text(">0");
            svg
                .selectAll("#g")
                .data(valuetoshow)
                .enter()
                .append("rect")
                .attr("class", "legend")
                .attr("y", function (d, i) {
                    return 260 + i * 25;
                })
                .attr("x", 750)
                .attr("width", 25)
                .attr("height", 15)
                .attr("fill", (d) => color(d));
            console.log(valuetoshow);
            svg
                .selectAll("#g")
                .data(valuetoshow)
                .enter()
                .append("text")
                .attr("class", "legend")
                .attr("y", function (d, i) {
                    return 270 + i * 25;
                })
                .attr("x", 780)
                .attr("font-size", 10)
                .attr("fill","#aaa")
                .text(function (d) {
                    d=">"+d;
                    return d;
                });
            svg
                .select("#g")
                .selectAll("path")
                .data(data.features)
                .enter()
                .append("path")
                .attr("class", "storke")
                .style("fill", "White")
                .style("fill-opacity", "0.0")
                .attr("d", geopath);

            svg.call(
                d3
                    .zoom()
                    .extent([
                        [0, 0],
                        [1000, 900],
                    ])
                    .scaleExtent([1, 8])
                    .on("zoom", zoomed)
                    .on("wheel.zoom", null) <!-- 控制缩放 -->
            );

            function zoomed({transform}) {
                svg.transition().duration(300).attr("transform", transform);
            }
        });
    });
}




  function updateMapBySlider(event) {
    // 获取滑块的值
    const selectedDays = parseInt(event.target.value);

    // 根据滑块值计算对应日期
    const selectedDate = new Date(startDate);
    selectedDate.setDate(selectedDate.getDate() + selectedDays);

    // 更新日期
    year = selectedDate.getFullYear().toString();
    month = ('0' + (selectedDate.getMonth() + 1)).slice(-2);
    day = ('0' + selectedDate.getDate()).slice(-2);
    date.value = year + "-" + month + "-" + day;
    window.localStorage.setItem('ymd', year + '-' + month + '-' + day);
    // 重新绘制地图
    drawchinageo();
    }
function change(event) {
    //获取日期
    var date = document.querySelector("input[type='date']");
    ymd = date.value;
    year = ymd[0] + ymd[1] + ymd[2] + ymd[3];
    month = ymd[5] + ymd[6];
    day = ymd[8] + ymd[9];


    // 更新时间轴滑块的值
  const startDate = new Date("2013-01-01");
  const currentDate = new Date(year + '-' + month + '-' + day);
  const daysDiff = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24));
  document.getElementById("dateSlider").value = daysDiff;
    window.localStorage.ymd = ymd;
    drawchinageo();
}

window.addEventListener('storage', event => {
    if (event.key === 'ymd') {
        ymd = event.newValue;
        year = ymd[0] + ymd[1] + ymd[2] + ymd[3];
        month = ymd[5] + ymd[6];
        day = ymd[8] + ymd[9];
        date.value = year + "-" + month + "-" + day;

        d3.select("#svg").remove();
        d3.select("#svg1").remove();
        d3.select("#svg2").remove();
        d3.select("#svg3").remove();
        drawchinageo();
    }
})

let autoplay = false;
let sliderValue = 0;
let intervalId = null;

const playButton = document.getElementById('playButton');
playButton.addEventListener('click', toggleAutoplay);


// 添加其他按钮事件以切换到其他指标...
function toggleAutoplay() {
  autoplay = !autoplay;

  if (autoplay) {
    playButton.textContent = 'Pause';
    intervalId = setInterval(playSlider, 10000); // 每100毫秒移动滑块一次
  } else {
    playButton.textContent = 'Play';
    clearInterval(intervalId);
  }
}


function playSlider() {
  const slider = document.getElementById('dateSlider');

  // 获取当前日期
  const currentDate = new Date(year + '-' + month + '-' + day);
  // 计算当前日期与起始日期之间的天数差
  const daysDiff = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24));

  // 设置滑块值
  if (sliderValue <= 2190) {
     sliderValue= daysDiff;
    slider.value =  sliderValue; // 设置滑块值为当前日期与起始日期之间的天数差
    sliderValue++;
     slider.value=sliderValue;
  } else {
    autoplay = false;
    playButton.textContent = 'Play';
    clearInterval(intervalId);
  }

  // 更新地图
  updateMapBySlider({ target: { value: slider.value } });
}


drawchinageo();
// 按钮点击事件处理函数
// 按钮点击事件处理函数
// 假设指标数组

var indicators = [
    "AQI","PM2.5(微克每立方米)", "PM10(微克每立方米)", "SO2(微克每立方米)", "NO2(微克每立方米)", "CO(毫克每立方米)", "O3(微克每立方米)", "TEMP(K)", "RH(%)", "PSFC(Pa)"
];
function changeIndicator(indicator) {
    currentIndicator = indicator || "AQI"; // 使用指标参数或者默认为 "AQI"
    drawchinageo(); // 更新地图以显示新的指标数据
}

/* 示例按钮点击事件，将指标切换为 PM2.5
document.getElementById('btnPM25').addEventListener('click', function() {
    changeIndicator("PM2.5(微克每立方米)");
});
document.getElementById('btnPM10').addEventListener('click', function() {
    changeIndicator("PM10(微克每立方米)");
});
document.getElementById('btnSO2').addEventListener('click', function() {
    changeIndicator("SO2(微克每立方米)");
});
document.getElementById('btnNO2').addEventListener('click', function() {
    changeIndicator("NO2(微克每立方米)");
});
document.getElementById('btnCO').addEventListener('click', function() {
    changeIndicator("CO(毫克每立方米)");
});
document.getElementById('btnO3').addEventListener('click', function() {
    changeIndicator("O3(微克每立方米)");
});
document.getElementById('btnTEMP').addEventListener('click', function() {
    changeIndicator("TEMP(K)");
});
document.getElementById('btnRH').addEventListener('click', function() {
    changeIndicator("RH(%)");
});
document.getElementById('btnPSFC').addEventListener('click', function() {
    changeIndicator("PSFC(Pa)");
});
// 示例按钮点击事件，将指标切换为 AQI（使用默认参数）
document.getElementById('btnAQI').addEventListener('click', function() {
    changeIndicator(); // 如果没有传递指标参数，默认切换到 AQI
});
*/