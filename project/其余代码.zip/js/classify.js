/////////////////////////////////
//时间轴
const startDate = new Date("2013-01-01");
const endDate = new Date("2018-12-31");
 // 计算日期范围内的总天数
const totalDays = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24));
 // 添加事件监听器以响应时间轴滑块的变化
const slider = document.getElementById("dateSlider");
slider.addEventListener("input", updateMapBySlider);
/////////////////////////////////////
var input = document.querySelector("#date");
input.addEventListener("input", change);
var date = document.querySelector("input[type='date']");
var currentIndicator = "AQI"; // 默认显示 AQI 指标
var ymd = "2013-01-01";
var year = "2013";
var month = "01";
var day = "01";
console.log(ymd);
// 定义不同指标的颜色比例尺
const typeColors = {

     "标准型":"#2166ac",
    "偏钢铁型":"#67a9cf",
    "偏烟花型":"#d1e5f0",
    "偏机动车型":"#e0f3f8",
    "偏燃煤型":"#fddbc7",
    "偏沙尘型":"#ef8a62",
    "偏二次型":"#b2182b",
};


function drawchinageo() {
var url="../../data/classify/"+year+"/"+year+month+"/"+year+month+day+"_pollution_type.csv";
    d3.json("../../json/china.json").then(function (data) {
        //读取地图数据
        var projection = d3
            .geoMercator() //投影
            .center([84, 37])
            .translate([100, 250])
            .scale(600);

        var geopath = d3
            .geoPath() //生成地图path
            .projection(projection);

        d3.select("svg").remove();
        var svg = d3
            .select("#hotmap") //画一个svg画布
            .append("svg")
            .attr("width", "900")
            .attr("height", "500");
        var g = svg.append("g").attr("id", "g"); //画出地图

        d3.select('svg').selectAll('geopath').remove();
        svg.selectAll("geopath")
            .data(data.features)
            .enter()
            .append("path")
            .attr("d", geopath)
            .on("mouseover",function(d,i){
                d3.select(this)
                    .attr("opacity","0.4");
            })
            .on("mouseout",function(d,i){
                d3.select(this)
                    .transition()
                    .duration(500)
                    .attr("opacity","0");
            })
            .on("click",function(n,d){
                window.localStorage.name = d.properties.name;
                window.localStorage.year = year;
                window.localStorage.mon = month;
                window.localStorage.day = day;
            })
            .attr("fill", "rgba(248,244,244)")
            .attr("opacity","0")

        var g1 = svg.select("g");

        d3.csv(url).then(function (alldata) {
            //获取空气数据
            console.log(alldata);
            var location = g1
                .selectAll(".location") //根据经纬度坐标coor的位置添加g元素
                .data(alldata)
                .enter()
                .append("g")
                .attr("class", "location")
                .attr("transform", function (d) {
                    //计算标注点的位置
                    var coor = projection([d[" lon"], d[" lat"]]);
                    return "translate(" + coor[0] + "," + coor[1] + ")";
                });
                    location
                .append("circle")
                .attr("transform", `rotate(${8}) translate(0,0)`)
                .attr("r", 1.5);
                var rect = d3
            .selectAll(".location")
            .select("circle")
                  .attr("fill", (d) => {
                        return typeColors[d["type"]]; // 假设您的数据中有一个"type"属性表示每种类型
                    });

    const valuetoshow = Object.keys(typeColors);

// Draw legend
const legend = svg.selectAll(".legend")
  .data(valuetoshow)
  .enter()
  .append("g")
  .attr("class", "legend")
  .attr("transform", function (d, i) {
    return "translate(550," + (280 + i * 25) + ")";
  });

legend.append("rect")
  .attr("x", 0)
  .attr("width", 25)
  .attr("height", 15)
  .attr("fill", (d) => typeColors[d]);

legend.append("text")
  .attr("x", 30)
  .attr("y", 10)
  .attr("dy", ".35em")
  .attr("fill", "#aaa")
  .attr("font-size", 10)
  .text(function (d) {
    return d; // Assuming the legend text should be the type of pollutant
  });

            svg.select("#g")
                .selectAll("path")
                .data(data.features)
                .enter()
                .append("path")
                .attr("class", "storke")
                .style("fill", "White")
                .style("fill-opacity", "0.0")
                .attr("d", geopath);

            svg.call(
                d3
                    .zoom()
                    .extent([
                        [0, 0],
                        [1000, 900],
                    ])
                    .scaleExtent([1, 8])
                    .on("zoom", zoomed)
                    .on("wheel.zoom", null) <!-- 控制缩放 -->
            );

            function zoomed({transform}) {
                svg.transition().duration(300).attr("transform", transform);
            }
        });
    });
}




  function updateMapBySlider(event) {
    // 获取滑块的值
    const selectedDays = parseInt(event.target.value);

    // 根据滑块值计算对应日期
    const selectedDate = new Date(startDate);
    selectedDate.setDate(selectedDate.getDate() + selectedDays);

    // 更新日期
    year = selectedDate.getFullYear().toString();
    month = ('0' + (selectedDate.getMonth() + 1)).slice(-2);
    day = ('0' + selectedDate.getDate()).slice(-2);
    date.value = year + "-" + month + "-" + day;
    window.localStorage.setItem('ymd', year + '-' + month + '-' + day);
    // 重新绘制地图
    drawchinageo();
    }
function change(event) {
    //获取日期
    var date = document.querySelector("input[type='date']");
    ymd = date.value;
    year = ymd[0] + ymd[1] + ymd[2] + ymd[3];
    month = ymd[5] + ymd[6];
    day = ymd[8] + ymd[9];


    // 更新时间轴滑块的值
  const startDate = new Date("2013-01-01");
  const currentDate = new Date(year + '-' + month + '-' + day);
  const daysDiff = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24));
  document.getElementById("dateSlider").value = daysDiff;
    window.localStorage.ymd = ymd;
    drawchinageo();
}

window.addEventListener('storage', event => {
    if (event.key === 'ymd') {
        ymd = event.newValue;
        year = ymd[0] + ymd[1] + ymd[2] + ymd[3];
        month = ymd[5] + ymd[6];
        day = ymd[8] + ymd[9];
        date.value = year + "-" + month + "-" + day;

        d3.select("#svg").remove();
        d3.select("#svg1").remove();
        d3.select("#svg2").remove();
        d3.select("#svg3").remove();
        drawchinageo();
    }
})

let autoplay = false;
let sliderValue = 0;
let intervalId = null;

const playButton = document.getElementById('playButton');
playButton.addEventListener('click', toggleAutoplay);


// 添加其他按钮事件以切换到其他指标...
function toggleAutoplay() {
  autoplay = !autoplay;

  if (autoplay) {
    playButton.textContent = 'Pause';
    intervalId = setInterval(playSlider, 2000); // 每100毫秒移动滑块一次
  } else {
    playButton.textContent = 'Play';
    clearInterval(intervalId);
  }
}


function playSlider() {
  const slider = document.getElementById('dateSlider');

  // 获取当前日期
  const currentDate = new Date(year + '-' + month + '-' + day);
  // 计算当前日期与起始日期之间的天数差
  const daysDiff = Math.floor((currentDate - startDate) / (1000 * 60 * 60 * 24));

  // 设置滑块值
  if (sliderValue <= 2190) {
     sliderValue= daysDiff;
    slider.value =  sliderValue; // 设置滑块值为当前日期与起始日期之间的天数差
    sliderValue++;
     slider.value=sliderValue;
  } else {
    autoplay = false;
    playButton.textContent = 'Play';
    clearInterval(intervalId);
  }

  // 更新地图
  updateMapBySlider({ target: { value: slider.value } });
}


drawchinageo();

